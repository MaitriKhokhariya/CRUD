import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000/api",
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    try {
      if (error.response?.status === 401 && !original._retry) {
        original._retry = true;
        const refreshToken = localStorage.getItem("refreshToken");
        const res = await api.post("/auth/refresh", { refreshToken });
        localStorage.setItem("accessToken", res.data.accessToken);
        api.defaults.headers.common["Authorization"] = `Bearer ${res.data.accessToken}`;
        return api(original);
      }
    } catch (e) {
      // refresh failed
      localStorage.clear();
      window.location.href = "/";
      return Promise.reject(e);
    }
    return Promise.reject(error);
  }
);

// attach access token if present
const token = localStorage.getItem("accessToken");
if (token) api.defaults.headers.common["Authorization"] = `Bearer ${token}`;

export default api;
