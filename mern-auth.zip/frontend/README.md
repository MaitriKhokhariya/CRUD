Frontend README
----------------
1. npm install
2. npm run dev
3. Open http://localhost:5173
Note: Tailwind is included; Vite dev server runs on 5173 by default.
