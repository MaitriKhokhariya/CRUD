import express from "express";
import { register, login, refresh } from "../controllers/authController.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.post("/refresh", refresh);

router.get("/user", protect, (req, res) => res.json(req.user));
router.get("/admin", protect, adminOnly, (req, res) => res.json({ message: "Welcome Admin" }));

export default router;
