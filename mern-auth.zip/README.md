MERN Auth Boilerplate (JavaScript + Tailwind)
=============================================
Structure:
- backend/  (Express + Mongoose)
- frontend/ (Vite React + Tailwind)

Quick start:

Backend:
1. cd backend
2. cp .env.example .env  (edit with your Mongo URI and secrets)
3. npm install
4. npm run dev

Frontend:
1. cd frontend
2. npm install
3. npm run dev

Default ports:
- Backend: 5000
- Frontend: 5173

